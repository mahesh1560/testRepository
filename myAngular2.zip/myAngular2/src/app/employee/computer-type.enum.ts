export enum ComputerType {
}
