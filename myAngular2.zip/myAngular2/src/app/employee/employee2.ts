export interface Employee2 {
}
