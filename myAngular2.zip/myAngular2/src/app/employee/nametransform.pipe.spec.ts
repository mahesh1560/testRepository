import { NametransformPipe } from './nametransform.pipe';

describe('NametransformPipe', () => {
  it('create an instance', () => {
    const pipe = new NametransformPipe();
    expect(pipe).toBeTruthy();
  });
});
