import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mhesh',
  templateUrl: './mhesh.component.html',
  styleUrls: ['./mhesh.component.css']
})
export class MheshComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
